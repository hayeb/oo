package Assignment3;
/**
 * @author Ylja Remmits - 
 * @author Haye bohm - 
 *
 */
public class Jump {

	public Jump() {
		
	}
}
